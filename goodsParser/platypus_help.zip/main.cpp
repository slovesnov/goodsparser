/*
 * main.cpp

 *
 *       Created on: 07.08.2014
 *           Author: alexey slovesnov
 * copyright(c/c++): 2014-doomsday
 *           E-mail: slovesnov@yandex.ru
 *         homepage: slovesnov.users.sourceforge.net
 */

#include <stdio.h>
#include <string.h>
#include <string>
#include <assert.h>

#include <experimental/filesystem>
using namespace std::experimental::filesystem;

#include "c:/msys64/mingw32/include/minizip/unzip.h"

/* this code do references from *.zip files from platypus dir for
 * http://slovesnov.users.sourceforge.net/index.php?platypus,russian page
 *
 * need to add "minizip" & "stdc++fs" (filesystem) to linker
 * linker library search path "c:\msys64\mingw32\bin" for minizip
 */
std::string unzipFile(std::string filepath);

typedef std::pair<int, std::string> IntString;

int main() {
	const char PATH[] = R"(D:\slovesno\site\platypus)";
	const char* MONTH_RU[] = {
			"������",
			"�������",
			"����",
			"������",
			"���",
			"����",
			"����",
			"������",
			"��������",
			"�������",
			"������",
			"�������" };
	const char* MONTH_EN[] = {
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec" };

#define D(a,s) const char a[]=s;const int a##_LEN=strlen(a);
	D(PLATYPUS, "platypus");
	D(END, ".zip");
	D(GOODS, "goods=");
#undef D

	const char*p;
	int i, day, month, year;
	std::string s, s1, path, name;
	char buff[1024];
	size_t t, w;
	std::size_t found;
	std::vector<IntString> data;

	for (auto& pa : directory_iterator(PATH)) {
		if (is_directory(pa)) {
			continue;
		}

		path = pa.path().string();
		found = path.rfind('\\');
		assert(found != std::string::npos);
		name = path.substr(found + 1);
		p = name.c_str();
		i = name.length();
		if (i < END_LEN || strncmp(p + i - END_LEN, END, END_LEN) != 0
				|| strncmp(p, PLATYPUS, PLATYPUS_LEN) != 0) {
			continue;
		}
		p += PLATYPUS_LEN;
		for (i = 0; i < 12; i++) {
			if (strncmp(p + 2, MONTH_EN[i], strlen(MONTH_EN[i])) == 0) {
				break;
			}
		}
		assert(i < 12);

		s = MONTH_RU[i];
		if (i == 2 || i == 7) {
			s += "�"; //"�����" "�������"
		}
		else {
			s = s.substr(0, s.length() - 1) + "�";
		}
		day = atoi(p);
		month = i + 1;
		year = atoi(p + 5);
		sprintf(buff, "<tr><td><a href=\"platypus/%s\">%d %s %d ����</a>",
				name.c_str(), day, s.c_str(), year);
		s1 = buff;

		s = unzipFile(path);
		t = s.rfind(GOODS);
		assert(t != std::string::npos);
		t += GOODS_LEN;
		w = s.find('\n', t + 1);
		assert(w != std::string::npos);
		sprintf(buff, "<td> ������� %.*s,<td> ����� %.2lf ��,<td> ���� %.2lf ��\n", w - t - 1,
				s.c_str() + t, file_size(pa) / 1024. / 1024.,
				s.length() / 1024. / 1024.);
		s1 += buff;
		data.push_back( { (year * 100 + month) * 100 + day, s1 });

	}

	std::sort(data.begin(), data.end(),
			[](IntString const& a, IntString const& b) {return a.first < b.first;});

	for (auto const&a : data) {
		printf("%s", a.second.c_str());
	}

	return 0;
}

//code copied from bridge project
const char dir_delimter = '/';
const int MAX_FILENAME = 512;
const int READ_SIZE = 8192;

std::string unzipFile(std::string filepath) {
	unzFile zipfile = unzOpen(filepath.c_str());
	if (zipfile == NULL) {
		printf("%s: not found", filepath.c_str());
		return "";
	}

	// Get info about the zip file
	unz_global_info global_info;
	if (unzGetGlobalInfo(zipfile, &global_info) != UNZ_OK) {
		printf("could not read file global info");
		unzClose(zipfile);
		return "";
	}

	// Buffer to hold data read from the zip file.
	char read_buffer[READ_SIZE];
	std::string unzipped;

	// Loop to extract all files
	uLong i;

	if (global_info.number_entry != 1) {
		printf("error: global_info.number_entry!=1");
	}

	for (i = 0; i < global_info.number_entry; ++i) {
		// Get info about current file.
		unz_file_info file_info;
		char filename[MAX_FILENAME];
		if (unzGetCurrentFileInfo(zipfile, &file_info, filename, MAX_FILENAME,
		NULL, 0, NULL, 0) != UNZ_OK) {
			printf("could not read file info\n");
			unzClose(zipfile);
			return "";
		}

		// Check if this entry is a directory or file.
		const size_t filename_length = strlen(filename);
		if (filename[filename_length - 1] == dir_delimter) {
			// Entry is a directory, so create it.
			//printf( "dir:%s", filename );
			//mkdir( filename );
		}
		else {
			// Entry is a file, so extract it.
			//printf( "file:%s", filename );
			if (unzOpenCurrentFile(zipfile) != UNZ_OK) {
				printf("could not open file");
				unzClose(zipfile);
				return "";
			}

			int error = UNZ_OK;
			do {
				error = unzReadCurrentFile(zipfile, read_buffer, READ_SIZE);
				if (error < 0) {
					printf("error %d", error);
					unzCloseCurrentFile(zipfile);
					unzClose(zipfile);
					return "";
				}

				// Write data to file.
				if (error > 0) {
					unzipped.append(read_buffer, error);//error - number of bytes,append this bytes
				}
			} while (error > 0);

		}

		unzCloseCurrentFile(zipfile);

		// Go the the next entry listed in the zip file.
		if ((i + 1) < global_info.number_entry) {
			if (unzGoToNextFile(zipfile) != UNZ_OK) {
				printf("cound not read next file");
				unzClose(zipfile);
				return "";
			}
		}
	}

	unzClose(zipfile);

	return unzipped;

}
