/*
 * main.cpp
 *
 *  Created on: 11.12.2017
 *      Author: alexey slovesnov
 *
 *
 */

/*
 project > properties > c/c++ build > settings
 on right MinGW C++ LInker > Libraries add Urlmon, iconv

 https didn't downloaded using ie, for chrome all ok
 But URLDownloadToFile using ie browser
 i used "tools", "internet options", "advanced" tab, "security" and checks all ssl & tls checkboxes
 https://social.msdn.microsoft.com/Forums/ie/en-US/4e39a225-3745-4e2f-bd91-c6fd725d4de4/urldownloadtofile-not-working-in-windows-7-with-https?forum=ieextensiondevelopment
 */

#include "Goods.h"

#define RELEASE

#ifdef RELEASE
int main() {
	/*
	 * parameter true means load all files from internet, otherwise works with saved local copy
	 * full loading from internet takes about 25 minutes. If use stored files it takes about 30sec
	 * for the first time, and 2 seconds for 2nd etc times
	 */

	Goods g(1);
}

#else

int main() {
	iconv_t foo = iconv_open("UTF-8", "cp1251");
	if (foo == iconv_t(-1) ) {
		if (errno == EINVAL) {
			fprintf(stderr, "Conversion is not supported");
		}
		else {
			fprintf(stderr, "Initialization failure:\n");
		}
		return 0;
	}

	const std::string s="��";
	char *from = (char*)(&s[0]);
	size_t ibl = s.length(); // len of iso

	// the converted string can be four times larger
	// then the original, as the largest known char width is 4 bytes.
	size_t obl = 2*s.length();// len of converted
	char *out = new char[obl];

	// we need to store an additional pointer that targets the
	// start of converted. (iconv modifies the original 'converted')
	char *converted = out;

	// do it!
	size_t ret = iconv(foo, &from, &ibl, &converted, &obl);

	// if iconv fails it returns -1
	if (ret == (size_t) -1) {
		printf("result -1 %d %d\n",ibl,obl);
		perror("iconv");
	}
	else {
		// other wise the number of converted bytes
		printf("%u bytes left %d %d\n", ret,ibl,obl);
		std::string o(out,2*s.length()-obl);
		printf("result [%s] original [%s]\n", o.c_str(),s.c_str());
	}
	delete[]out;
	iconv_close(foo);
}

#endif
