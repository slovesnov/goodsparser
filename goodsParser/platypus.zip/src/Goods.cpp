/*
 * Goods.cpp
 *
 *  Created on: 12.12.2017
 *      Author: alexey slovesnov
 */

/*
 * at the end check "[ "," ]"
 */
#include "Goods.h"
#include <sys/stat.h>
#include <time.h>
#include <Urlmon.h>
#include <Windows.h>

#ifndef USE_MY_ICONV
#include "iconv.hpp"
#endif

const char* TYPE[] = { "��", "100 �", "" };
const int TYPE_SIZE = SIZE(TYPE);
std::string TYPE_UTF8[TYPE_SIZE];

const int BUFFER_SIZE = 2 * 1024 * 1024;
const int DOT_PER_PAGES = 25;

const char HTML_DIR[] = "html"; //dir with loaded html files
const char STRANGE_FILE_NAME[] = "strange.txt";
const char *CODE_PAGE[] = { "cp1251", "UTF-8" };

#ifdef USE_MY_ICONV
iconv_t Goods::conv[2];
char Goods::m_iconvBuffer[Goods::ICONV_BUFFER_SIZE];
#else
converter con[2]= {
	converter(CODE_PAGE[0],CODE_PAGE[1])
	,converter(CODE_PAGE[1],CODE_PAGE[0])
};
#endif

std::string text[] = { "</a></div><div class=\"goods_view_box-rating\">", //0
		"<div class=\"goods_price-item current", //1
		"���. ", //2
		"<div class=\"signature\">��������: 1 �� ", //3
		"\" data-weight=\"/", //4
		" big\" data-weight=\"", //5
};

Goods::Goods(bool loadFiles, int startParseCategory) {
	int i, j, k;
	std::string s, url;
	const char*p, *p1, *p2;

	m_totalFiles = 0;
	m_loadFiles = loadFiles;
	m_strangeEncodeCount = 0;
	m_vendorSkip = 0;
	clock_t begin = clock();

	m_buffer = new char[BUFFER_SIZE];
	assert(m_buffer);

	FILE*f = fopen("encode.txt", "r");
	assert(f);
	for (i = 0; fgets(m_buffer, 1024, f); i++) {
		if (i != 0) {
			j = strlen(m_buffer) - 1;
			assert(j > 0);
			if (m_buffer[j] == '\n') {
				m_buffer[j] = 0;
			}
			p = strchr(m_buffer, '/');
			assert(p);
			m_encode.push_back( { std::string(m_buffer, p - m_buffer), p + 1 });
		}
	}
	fclose(f);

#ifdef USE_MY_ICONV
	for (i = 0; i < 2; i++) { //before encode
		//iconv_open(out,in)
		conv[i] = iconv_open(CODE_PAGE[i], CODE_PAGE[1 - i]);
		assert(conv[i] != iconv_t(-1));
	}
#endif
	m_nameReplace= {
		"TRESemm\xC3\xA9","TRESemme",
		"Caf\xC3\xA9","Cafe",
		encode("����������",1)+"\xcc\x86",encode("����������",1),
		encode("�������",1)+"\xcc\x86",encode("�������",1)
	};

	for (i = 0; i < SIZE(text); i++) {
		text[i] = encode(text[i], true);
	}

	for (i = 0; i < TYPE_SIZE; i++) {
		TYPE_UTF8[i] = encode(TYPE[i], true);
	}

	struct stat st = { 0 };
	if (stat(HTML_DIR, &st) == -1) {
		mkdir(HTML_DIR);
	}

	GetCurrentDirectory(BUFFER_SIZE, m_buffer);
	m_currentDir = m_buffer;

	time_t rawtime;
	tm * timeinfo;
	time(&rawtime);
	timeinfo = localtime(&rawtime);
	strftime(m_buffer, 80, "platypus%d%b%Y.txt", timeinfo);
	m_out = fopen(m_buffer, "w+");
	assert(m_out);
	strftime(m_buffer, 80, "%d %b %Y %H:%M:%S", timeinfo);
	toConsoleFile("%s\n", m_buffer);

	m_strange = fopen(STRANGE_FILE_NAME, "w+");
	assert(m_strange);

	//load categories
	url = PLATYPUS_URL + "cat";
	loadUrlToBuffer(url);

	const char * F[] = { "<ul>", "</ul>", "<a href=\"/cat/" };
	k = 0;
	p = m_buffer;
	while (1) {
		p2 = p;
		j = -1;
		for (i = 0; i < SIZE(F); i++) {
			p1 = strstr(p, F[i]);
			if (!p1) {
				continue;
			}
			if (i == 0 || p1 < p2) {
				p2 = p1;
				j = i;
			}
		}
		if (j == -1) {
			break;
		}
		//println("%d",j);
		p = p2 + strlen(F[j]);
		if (j == 0) {
			k++;
		}
		else if (j == 1) {
			k--;
		}
		else if (k == 1) {
			s = innerString(p, p1, '"');
			try {
				i = parseInt(s);

				p1 = find(p1, '>', true);
				s = innerString(p1, p);

				for (auto& a : m_categories) {
					assert(a.first != i);
				}

				m_categories.push_back( { i, s });

			}
			catch (...) {
				printinfo
				throw;
			}
		}
	}

	for (m_it = m_categories.begin(); m_it != m_categories.end(); m_it++) {
		if (m_it - m_categories.begin() + 1 < startParseCategory) {
			continue;
		}
		loadParseCategory();
	}

	/*
	 //m_loadFiles=false;
	 url=PLATYPUS_URL+format("cat/%d/page/%d",495,26);
	 loadParseFile(url,false);
	 */

	if (m_strangeEncodeCount) {
		toConsoleFile("strange encode goods found %d read %s file\n",
				m_strangeEncodeCount, STRANGE_FILE_NAME);
	}

	i = (clock() - begin) / CLOCKS_PER_SEC;
	toConsoleFile("the end time %02d:%02d files=%s goods=%s\n", i / 60, i % 60,
			intToString(m_totalFiles, ',').c_str(),
			intToString(m_vendor.size(), ',').c_str());

	fclose(m_out);
	fclose(m_strange);
	delete[] m_buffer;

#ifdef USE_MY_ICONV
	for (i = 0; i < 2; i++) {
		iconv_close(conv[i]);
	}
#endif
}

int Goods::getType(const std::string& s) {
	int i = 0;
	for (auto& a : TYPE_UTF8) {
		if (s == a) {
			return i;
		}
		i++;
	}
	println("error type not found [%s]", s.c_str());
	assert(0);
	return -1;
}

double Goods::getPrice(const std::string& s) {
	char*p;
	std::string q = replaceAll(s, ",", ".");
	q = replaceAll(q, " ", "");		//"1 115,00" = 1115 roubles

	double price = strtod(q.c_str(), &p);
	assert(p == q.c_str() + q.length());
	return price;
}

//parse full string
int Goods::parseInt(const std::string& s) {
	char*p;
	int r = strtol(s.c_str(), &p, 10);
	assert(p == s.c_str() + s.length());
	return r;
}

std::string Goods::replaceAll(std::string subject, const std::string& from,
		const std::string& to) {
	size_t pos = 0;
	while ((pos = subject.find(from, pos)) != std::string::npos) {
		subject.replace(pos, from.length(), to);
		pos += to.length();
	}
	return subject;
}

std::string Goods::encode(const std::string& s, bool toUtf8, int code) {
	//Note if try to encode full file throw error
#ifdef USE_MY_ICONV
	char *from = (char*) s.c_str();
	size_t ibl = s.length() + 1; // length of string + zero byte

	/* the converted string can be two times larger
	 * every symbol cp1251 russian chars->utf8 gives two bytes for every char
	 * +1 end zero byte
	 */

	size_t obl = 2 * s.length() + 1; // len of converted
	assert(obl <= ICONV_BUFFER_SIZE);

	// we need to store an additional pointer that targets the
	// start of converted. (iconv modifies the original 'converted')
	char *converted = m_iconvBuffer;

	// do it!
	size_t ret = iconv(conv[toUtf8], &from, &ibl, &converted, &obl);
	//ret==-1 on error http://man7.org/linux/man-pages/man1/iconv.1.html
	if (code) {
		if (ret == (size_t) -1) {
			for (auto const&a : m_encode) {
				if (a.first == s) {
					return encode(a.second, false);
				}
			}
			m_strangeEncodeCount++;
			fprintf(m_strange, "[%s]%d\n", s.c_str(), code);
			return s;
		}
	}
	else {
		assert(ret != (size_t )-1);
	}

	return m_iconvBuffer;
#else
	std::string r;
	con[toUtf8].convert(s, r);
	return r;
#endif
}

int Goods::getFileSize(const std::string& path) {
	struct stat stat_buf;
	int rc = stat(path.c_str(), &stat_buf);
	return rc == 0 ? stat_buf.st_size : -1;
}

std::string Goods::getSavedFileName(std::string url) {
	return HTML_DIR
			+ ("/" + replaceAll(url.substr(PLATYPUS_URL.length()), "/", "_"))
			+ ".html";
}

void Goods::loadParseFile(const std::string& url, bool firstPage) {
	std::string s, o, s1;
	const char*p, *p1, *p2;
	int i, j;
	loadUrlToBuffer(url);
	std::string name;
	int vendorCode;
	double price;
	int type;

	for (i = 0, p = m_buffer; (p = strstr(p, text[0].c_str())) != NULL; i++) {
		for (p1 = p - 1; *p1 != '>'; p1--)
			;
		p1++;
		name = std::string(p1, p - p1);

		p += text[0].length();
		p1 = find(p, text[1]);

		for (j = 4; j < 6; j++) {
			if (strncmp(p1, text[j].c_str(), text[j].length()) == 0) {
				p1 += text[j].length();
				break;
			}
		}

		type = getType(innerString(p1, p2, '"'));

		p1 = find(p2, '>');
		price = getPrice(innerString(p1, p2));

		p1 = find(p, text[2]);
		assert(p1);

		s = innerString(p1, p);
		vendorCode = parseInt(s);

		p = p1;

		s = TYPE[type];
		if (!s.empty()) {
			s = "/" + s;
		}

		s1 = name;
		for (j = 0; j < int(m_nameReplace.size()); j += 2) {
			s1 = replaceAll(s1, m_nameReplace[j], m_nameReplace[j + 1]);
		}
		name = encode(s1, false, vendorCode);
		name = replaceAll(name, "\xa0", " ");//before trim
		trim(name);

		s1=format("[%s] %.2lf%s %d\n", name.c_str(), price, s.c_str(),
				vendorCode);
		auto const a=m_vendor.insert({vendorCode,s1});
		if (a.second) {
			o += s1;
		}
		else {
			if(a.first->second!=s1){
				fprintf(m_strange, "[%s][%s]", a.first->second.c_str(), s1.c_str());
			}
			//assert(a.first->second==s1);
			m_vendorSkip++;
		}

		//break;
	}

	if (i == 0) {	//in case no goods found set p2 anyway, used below
		p2 = m_buffer;
	}

	if (firstPage) {
		m_currentPage = 1;	//for output

		//p=NULL for is break, so use last valid ptr p2
		if (strstr(p2, text[3].c_str()) == NULL) {
			m_totalPagesInCurrentCategory = 1;
		}
		else {
			p1 = find(p2, text[3], true);
			s = innerString(p1, p2);
			try {
				m_totalPagesInCurrentCategory = parseInt(s);
			}
			catch (...) {
				printinfo
				throw;
			}
			assert(m_totalPagesInCurrentCategory >= 1);
		}
	}

	s = format("%s goods=%d page=%d/%d category=%d/%d",
			url.c_str() + HTTPS_WWW.length(), i, m_currentPage,
			m_totalPagesInCurrentCategory, m_it - m_categories.begin() + 1,
			int(m_categories.size()));
	s1 = encode(m_it->second, false);
	trim(s1);
	if (firstPage && !s1.empty()) {
		s += " [" + s1 + "]";
	}

	if (firstPage) {
		toConsoleFile("%s", s.c_str());
		fprintf(m_out, "\n");
	}
	else {
		if (m_currentPage % DOT_PER_PAGES == 0) {
			printf(".");
		}
	}
	if (m_currentPage == m_totalPagesInCurrentCategory) {
		printf("\n");
	}
	fflush(stdout);

	fprintf(m_out, "%s", o.c_str());
}

void Goods::loadParseCategory() {
	int i;
	const int n = m_it->first;
	std::string url = PLATYPUS_URL + format("cat/%d", n);
	loadParseFile(url, true);
	m_totalFiles += m_totalPagesInCurrentCategory;
	for (i = 2; i <= m_totalPagesInCurrentCategory; i++) {
		//https://www.utkonos.ru/cat/27/page/2
		url = PLATYPUS_URL + format("cat/%d/page/%d", n, i);
		m_currentPage = i;
		loadParseFile(url, false);
	}
}

bool Goods::loadFile(std::string url) {
	//download file https://stackoverflow.com/questions/5184988/should-i-use-urldownloadtofile
	if (!m_loadFiles) {
		return true;
	}

	std::string s = getSavedFileName(url);
	std::string path = m_currentDir + G_DIR_SEPARATOR + s;
	HRESULT res = URLDownloadToFile(NULL, url.c_str(), path.c_str(), 0, NULL);

	if (res == S_OK) {
		return true;
	}
	else if (res == E_OUTOFMEMORY) {
		println("Buffer length invalid, or insufficient memory");
	}
	else if (res == INET_E_DOWNLOAD_FAILURE) {
		println("URL is invalid [%s][%s]", url.c_str(), path.c_str());
	}
	else {
		println("Other error: %x", res);
	}

	return false;
}

void Goods::toConsoleFile(const char* _format, ...) {
	char buffer[2048];
	va_list args;
	va_start(args, _format);
	vsprintf(buffer, _format, args);
	va_end(args);

	printf("%s", buffer);
	fprintf(m_out, "%s", buffer);
}

std::string Goods::format(const char* _format, ...) {
	char buffer[2048];
	va_list args;
	va_start(args, _format);
	vsprintf(buffer, _format, args);
	va_end(args);
	return buffer;
}

void Goods::loadUrlToBuffer(std::string url) {
	if (!loadFile(url)) {
		assert(0);
	}
	std::string s = getSavedFileName(url);
	const char*p = s.c_str();
	int i = getFileSize(s);
	if (i >= BUFFER_SIZE) {
		println("%s %d > %d", url.c_str() + HTTPS_WWW.length(), i, BUFFER_SIZE);
		throw 0;
	}
	FILE*f = fopen(p, "r");
	if (!f) {
		println("cann't find file %s url %s", p, url.c_str() + HTTPS_WWW.length());
		throw 0;
	}
	size_t sz = fread(m_buffer, 1, i, f);
	assert(int(sz) <= i);
	fclose(f);
	m_buffer[sz] = 0;
}
