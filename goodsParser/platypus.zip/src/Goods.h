/*
 * Goods.h
 *
 *  Created on: 12.12.2017
 *      Author: alexey slovesnov
 */

#ifndef GOODS_H_
#define GOODS_H_

#define USE_MY_ICONV

#include <string>
#include <assert.h>
#include <string.h>
#include <vector>
#include <map>
#include <algorithm>

#ifdef USE_MY_ICONV
#include <iconv.h>
#endif

#define SIZE(arr)		int(sizeof (arr) / sizeof ((arr)[0]))
#define G_DIR_SEPARATOR '\\'
const std::string HTTPS_WWW = "https://www.";
const std::string PLATYPUS_URL = HTTPS_WWW + "utkonos.ru/";

typedef std::vector<std::string> VString;
typedef std::pair<int, std::string> IntString;
typedef std::vector<IntString> IntStringV;
typedef IntStringV::const_iterator IntStringVCI;
typedef std::vector<std::pair<std::string, std::string>> VStringString;

#ifdef NDEBUG

#define println(f, ...)  ((void)0);
#define printinfo ((void)0);

#else

#define println(f, ...) printf("%-40s %s:%d %s\n",\
		Goods::format(f,##__VA_ARGS__).c_str(),Goods::shortFileName(__FILE__).c_str()\
		,__LINE__,__PRETTY_FUNCTION__);

#define printinfo println("")

#endif

class Goods {
public:
#ifdef USE_MY_ICONV
	static iconv_t conv[2];
	static const int ICONV_BUFFER_SIZE = 1024;
	static char m_iconvBuffer[ICONV_BUFFER_SIZE];
#endif

	FILE*m_out, *m_strange;
	bool m_loadFiles;
	IntStringV m_categories;
	char*m_buffer;
	std::string m_currentDir;
	VStringString m_encode;
	int m_strangeEncodeCount;
	std::map<int,std::string> m_vendor;
	int m_vendorSkip;
	VString m_nameReplace;

	//running counters just for output
	IntStringVCI m_it;
	int m_currentPage;
	int m_totalPagesInCurrentCategory; //total pages in proceeding category
	int m_totalFiles;

	Goods(bool loadFiles, int startParseCategory = 1);
	int getType(std::string const& s);
	double getPrice(std::string const& s);
	int getVendorCode(std::string const& s);

	void loadParseFile(std::string const& url, bool firstPage);
	void loadParseCategory();

	static int parseInt(std::string const& s);
	std::string encode(const std::string& s, bool toUtf8, int code = 0);
	static std::string replaceAll(std::string subject, const std::string& from,
			const std::string& to);
	static int getFileSize(const std::string& path);
	static std::string getSavedFileName(std::string url);
	static std::string format(const char* _format, ...);

	bool loadFile(std::string url);
	void toConsoleFile(const char* _format, ...);

	void loadUrlToBuffer(std::string url);

	static const char* find(const char*p, const char*what, bool add = true) {
		const char*r = strstr(p, what);
		if (r == NULL) {
			println("ERROR [%s][%.50s]", what, p);
			assert(0);
		}

		if (add) {
			r += strlen(what);
		}
		return r;
	}

	static const char* find(const char*p, const char what, bool add = true) {
		const char*r = strchr(p, what);
		assert(r);
		if (add) {
			r++;
		}
		return r;
	}

	static const char* find(const char*p, const std::string& what,
			bool add = true) {
		return find(p, what.c_str(), add);
	}

	static std::string innerString(const char*p1, const char*& p2,
			const char breakChar = '<') {
		p2 = strchr(p1, breakChar);
		assert(p2);
		return std::string(p1, p2 - p1);
	}

	static std::string intToString(int v, char separator = ' ') { //format(1234567,3)="1 234 567"
		const int digits = 3;
		char b[16];
		std::string s;
		sprintf(b, "%d", v);
		int i;
		char*p;
		for (p = b, i = strlen(b) - 1; *p != 0; p++, i--) {
			s += *p;
			if (i % digits == 0 && i != 0) {
				s += separator;
			}
		}
		return s;
	}

	static std::string shortFileName(const char*file) {
		const char*p = strrchr(file, G_DIR_SEPARATOR);
		return p ? p + 1 : file;
	}

	// trim from start (in place)
	static inline void ltrim(std::string &s) {
	    s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](int ch) {
	        return !std::isspace(ch);
	    }));
	}

	// trim from end (in place)
	static inline void rtrim(std::string &s) {
	    s.erase(std::find_if(s.rbegin(), s.rend(), [](int ch) {
	        return !std::isspace(ch);
	    }).base(), s.end());
	}

	// trim from both ends (in place)
	static inline void trim(std::string &s) {
	    ltrim(s);
	    rtrim(s);
	}

};

#endif /* GOODS_H_ */
